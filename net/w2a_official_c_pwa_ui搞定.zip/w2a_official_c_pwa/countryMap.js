window.countryButtonMap = {
  Brazil: 'brl',
  India: 'hi',
  English: 'en',
}